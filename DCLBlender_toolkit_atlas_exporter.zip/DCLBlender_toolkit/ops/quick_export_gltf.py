import bpy
import os

from .export_material_atlas import run_material_atlas_optimization


class OBJECT_OT_quick_export_gltf(bpy.types.Operator):
    bl_idname = "object.quick_export_gltf"
    bl_label = "Quick Export glTF"
    bl_description = "One-click glTF/GLB export with Decentraland-optimized settings"
    bl_options = {'REGISTER', 'UNDO'}

    export_format: bpy.props.EnumProperty(
        name="Format",
        description="Export file format",
        items=[
            ('GLB', 'glTF Binary (.glb)', 'Single binary file (recommended for DCL)'),
            ('GLTF_SEPARATE', 'glTF Separate (.gltf + .bin)', 'Separate files'),
        ],
        default='GLB',
    )

    export_selected: bpy.props.BoolProperty(
        name="Selected Only",
        description="Export only selected objects",
        default=False,
    )

    apply_modifiers: bpy.props.BoolProperty(
        name="Apply Modifiers",
        description="Apply modifiers before exporting",
        default=True,
    )

    export_cameras: bpy.props.BoolProperty(
        name="Export Cameras",
        description="Include cameras in the export",
        default=False,
    )

    export_lights: bpy.props.BoolProperty(
        name="Export Lights",
        description="Include lights in the export (punctual lights extension)",
        default=False,
    )

    atlas_optimize_enabled: bpy.props.BoolProperty(
        name="Atlas Optimize (2/4 x 512)",
        description="Non-destructive export-time atlas optimization for strict compatible groups",
        default=False,
    )

    atlas_mode: bpy.props.EnumProperty(
        name="Atlas Mode",
        description="Atlas optimization mode",
        items=[
            ('STRICT_2_OR_4_512_TO_1024', 'Strict 2/4 (512)', 'Merge exact compatible groups of 4 (to 1024x1024) or 2 (to 512x1024)'),
            ('STRICT_4X512_TO_1024', 'Strict 4x512 to 1x1024', 'Merge exact groups of 4 compatible 512 materials'),
        ],
        default='STRICT_2_OR_4_512_TO_1024',
    )

    atlas_max_size: bpy.props.IntProperty(
        name="Atlas Max Size",
        description="Maximum atlas dimension (fixed to 1024 in v1)",
        default=1024,
        min=1024,
        max=1024,
    )

    atlas_scope: bpy.props.EnumProperty(
        name="Atlas Scope",
        description="Atlas scope source",
        items=[
            ('SELECTED_OR_SCENE', 'Use Export Scope', 'Follows Selected Only toggle'),
        ],
        default='SELECTED_OR_SCENE',
    )

    atlas_debug_report: bpy.props.BoolProperty(
        name="Atlas Debug Report",
        description="Include compatibility and skip warnings in export report",
        default=True,
    )

    export_folder: bpy.props.StringProperty(
        name="Export Folder",
        description="Subfolder name for the export (created next to the .blend file)",
        default="export",
    )

    filename: bpy.props.StringProperty(
        name="Filename",
        description="Name of the exported file (without extension)",
        default="scene",
    )

    def _target_export_objects(self, context):
        if self.export_selected:
            return list(context.selected_objects)
        return list(context.scene.objects)

    def _export_with_temp_selection(self, context, objects, kwargs):
        view_layer = context.view_layer
        prev_selected = list(context.selected_objects)
        prev_active = view_layer.objects.active

        try:
            for obj in prev_selected:
                obj.select_set(False)

            active = None
            for obj in objects:
                if obj.name in context.scene.objects:
                    obj.select_set(True)
                    if active is None:
                        active = obj

            if active:
                view_layer.objects.active = active

            bpy.ops.export_scene.gltf(**kwargs)
        finally:
            current_selected = list(context.selected_objects)
            for obj in current_selected:
                obj.select_set(False)

            for obj in prev_selected:
                if obj.name in context.scene.objects:
                    obj.select_set(True)

            if prev_active and prev_active.name in context.scene.objects:
                view_layer.objects.active = prev_active

    def _format_optimization_report(self, report):
        summary = (
            f"Atlas candidates: {report.get('candidate_materials', 0)} | "
            f"Merged quartets: {report.get('merged_quartets', 0)} | "
            f"Merged pairs: {report.get('merged_pairs', 0)} | "
            f"Leftovers: {report.get('leftover_materials', 0)} | "
            f"Est. draw-call reduction: -{report.get('drawcall_reduction_estimate', 0)} | "
            f"Resized to 512: {report.get('resized_textures_to_512', 0)}"
        )

        stats = (
            f"Materials {report.get('before_materials', 0)}->{report.get('after_materials', 0)} | "
            f"Textures {report.get('before_textures', 0)}->{report.get('after_textures', 0)}"
        )

        warnings = report.get('warnings', [])
        if warnings and self.atlas_debug_report:
            return f"{summary} | {stats} | Warnings: {len(warnings)}"
        return f"{summary} | {stats}"

    def execute(self, context):
        # Determine output directory
        if bpy.data.filepath:
            blend_dir = os.path.dirname(bpy.data.filepath)
            out_dir = os.path.join(blend_dir, self.export_folder)
        else:
            home_dir = os.path.expanduser("~")
            out_dir = os.path.join(home_dir, "Desktop", self.export_folder)

        os.makedirs(out_dir, exist_ok=True)

        ext = ".glb" if self.export_format == 'GLB' else ".gltf"
        filepath = os.path.join(out_dir, self.filename + ext)

        # Build export kwargs
        kwargs = {
            'filepath': filepath,
            'export_format': self.export_format,
            'use_selection': self.export_selected,
            'export_apply': self.apply_modifiers,
            'export_cameras': self.export_cameras,
            'export_lights': self.export_lights,
            'export_yup': True,
        }

        atlas_state = None
        optimization_report = None

        try:
            if self.atlas_optimize_enabled and self.atlas_mode in {'STRICT_2_OR_4_512_TO_1024', 'STRICT_4X512_TO_1024'}:
                export_objects = self._target_export_objects(context)
                atlas_state, optimization_report = run_material_atlas_optimization(
                    context,
                    export_objects,
                    mode=self.atlas_mode,
                    debug_report=self.atlas_debug_report,
                )

                atlas_kwargs = dict(kwargs)
                atlas_kwargs['use_selection'] = True
                self._export_with_temp_selection(context, atlas_state.export_objects, atlas_kwargs)
            else:
                bpy.ops.export_scene.gltf(**kwargs)

            file_size = os.path.getsize(filepath) if os.path.exists(filepath) else 0
            size_str = self._format_size(file_size)

            if optimization_report:
                self.report({'INFO'}, f"Exported to {filepath} ({size_str})")
                self.report({'INFO'}, self._format_optimization_report(optimization_report))

                if self.atlas_debug_report:
                    for warning in optimization_report.get('warnings', [])[:8]:
                        self.report({'WARNING'}, warning)
                    extra = len(optimization_report.get('warnings', [])) - 8
                    if extra > 0:
                        self.report({'WARNING'}, f"... and {extra} more atlas warnings")
            else:
                self.report({'INFO'}, f"Exported to {filepath} ({size_str})")

        except Exception as e:
            if self.atlas_optimize_enabled:
                self.report({'WARNING'}, f"Atlas optimization failed, exporting without atlas: {str(e)}")
                try:
                    bpy.ops.export_scene.gltf(**kwargs)
                    file_size = os.path.getsize(filepath) if os.path.exists(filepath) else 0
                    size_str = self._format_size(file_size)
                    self.report({'INFO'}, f"Exported to {filepath} ({size_str})")
                    return {'FINISHED'}
                except Exception as fallback_err:
                    self.report({'ERROR'}, f"Fallback export failed: {str(fallback_err)}")
                    return {'CANCELLED'}

            self.report({'ERROR'}, f"Export failed: {str(e)}")
            return {'CANCELLED'}
        finally:
            if atlas_state:
                atlas_state.cleanup()

        return {'FINISHED'}

    def _format_size(self, size_bytes):
        if size_bytes < 1024:
            return f"{size_bytes} B"
        elif size_bytes < 1024 * 1024:
            return f"{size_bytes / 1024:.1f} KB"
        else:
            return f"{size_bytes / (1024 * 1024):.2f} MB"

    def draw(self, context):
        layout = self.layout

        layout.prop(self, "export_format")
        layout.separator()

        layout.prop(self, "filename")
        layout.prop(self, "export_folder")
        layout.separator()

        col = layout.column(align=True)
        col.prop(self, "export_selected")
        col.prop(self, "apply_modifiers")
        col.prop(self, "export_cameras")
        col.prop(self, "export_lights")

        layout.separator()
        box = layout.box()
        box.label(text="Material Atlas Optimization")
        box.prop(self, "atlas_optimize_enabled")

        sub = box.column(align=True)
        sub.enabled = self.atlas_optimize_enabled
        sub.prop(self, "atlas_mode")

        row = sub.row()
        row.enabled = False
        row.prop(self, "atlas_max_size")

        sub.prop(self, "atlas_scope")
        sub.prop(self, "atlas_debug_report")

        layout.separator()
        # Show output path preview
        if bpy.data.filepath:
            blend_dir = os.path.dirname(bpy.data.filepath)
            out_dir = os.path.join(blend_dir, self.export_folder)
        else:
            out_dir = os.path.join("~/Desktop", self.export_folder)

        ext = ".glb" if self.export_format == 'GLB' else ".gltf"
        layout.label(text=f"Output: {out_dir}/{self.filename}{ext}", icon='FILE')

    def invoke(self, context, event):
        # Default filename from blend file
        if bpy.data.filepath:
            blend_name = os.path.splitext(os.path.basename(bpy.data.filepath))[0]
            self.filename = blend_name
        return context.window_manager.invoke_props_dialog(self, width=500)
