import bpy


TILE_SIZE = 512
LAYOUT_4 = {
    "name": "4x512_to_1024",
    "width": 1024,
    "height": 1024,
    "tiles": [
        (0, TILE_SIZE),          # Top-left
        (TILE_SIZE, TILE_SIZE),  # Top-right
        (0, 0),                  # Bottom-left
        (TILE_SIZE, 0),          # Bottom-right
    ],
}
LAYOUT_2 = {
    "name": "2x512_to_512x1024",
    "width": 512,
    "height": 1024,
    "tiles": [
        (0, TILE_SIZE),  # Top
        (0, 0),          # Bottom
    ],
}


class ExportAtlasState:
    """Holds temporary scene data created for export and cleans it up."""

    def __init__(self, scene, temp_collection, export_objects, created_images, created_materials):
        self.scene = scene
        self.temp_collection = temp_collection
        self.export_objects = export_objects
        self.created_images = created_images
        self.created_materials = created_materials

    def cleanup(self):
        if self.temp_collection:
            if self.scene and self.temp_collection.name in self.scene.collection.children:
                self.scene.collection.children.unlink(self.temp_collection)

            objs = list(self.temp_collection.objects)
            for obj in objs:
                data = getattr(obj, "data", None)
                bpy.data.objects.remove(obj, do_unlink=True)
                if data and hasattr(data, "users") and data.users == 0:
                    data_type = type(data).__name__
                    if data_type == "Mesh":
                        bpy.data.meshes.remove(data)
                    elif data_type == "Camera":
                        bpy.data.cameras.remove(data)
                    elif data_type == "Light":
                        bpy.data.lights.remove(data)
                    elif data_type == "Armature":
                        bpy.data.armatures.remove(data)
            if self.temp_collection.users == 0:
                bpy.data.collections.remove(self.temp_collection)

        for mat in self.created_materials:
            if mat and mat.name in bpy.data.materials and bpy.data.materials[mat.name].users == 0:
                bpy.data.materials.remove(bpy.data.materials[mat.name])

        for img in self.created_images:
            if img and img.name in bpy.data.images and bpy.data.images[img.name].users == 0:
                bpy.data.images.remove(bpy.data.images[img.name])


class MaterialAnalysis:
    def __init__(self, material, key, base_image, normal_image, rough_source, metal_source):
        self.material = material
        self.key = key
        self.base_image = base_image
        self.normal_image = normal_image
        self.rough_source = rough_source
        self.metal_source = metal_source


class ChannelSource:
    def __init__(self, mode, image=None, channel=0, scalar=0.0):
        self.mode = mode
        self.image = image
        self.channel = channel
        self.scalar = scalar


class MaterialAtlasOptimizer:
    def __init__(self, context, export_objects, mode='STRICT_2_OR_4_512_TO_1024', debug_report=True):
        self.context = context
        self.scene = context.scene
        self.export_objects = export_objects
        self.mode = mode
        self.debug_report = debug_report
        self.created_images = []
        self.created_materials = []
        self.pixel_cache = {}
        self.normalized_512_cache = {}
        self.resized_from_sources = set()

    def run(self):
        temp_collection, duplicated = self._duplicate_export_objects()
        mesh_objects = [obj for obj in duplicated if obj.type == 'MESH']
        before_mats, before_tex = self._count_used_materials_textures(mesh_objects)

        report = {
            "candidate_materials": 0,
            "merged_quartets": 0,
            "merged_pairs": 0,
            "leftover_materials": 0,
            "drawcall_reduction_estimate": 0,
            "resized_textures_to_512": 0,
            "before_materials": before_mats,
            "before_textures": before_tex,
            "warnings": [],
        }

        analysis = self._collect_candidates(mesh_objects, report)
        report["candidate_materials"] = len(analysis)

        grouped = self._build_groups(analysis, report)

        for group_index, group in enumerate(grouped):
            try:
                atlas_material = self._build_atlas_material(group_index, group["items"], group["layout"])
                self._apply_group(mesh_objects, group["items"], group["layout"], atlas_material)
                if len(group["items"]) == 4:
                    report["merged_quartets"] += 1
                elif len(group["items"]) == 2:
                    report["merged_pairs"] += 1
            except Exception as exc:
                report["warnings"].append(
                    f"Group {group_index + 1} skipped: {exc}"
                )

        merged_count = (report["merged_quartets"] * 4) + (report["merged_pairs"] * 2)
        report["leftover_materials"] = max(0, len(analysis) - merged_count)
        report["drawcall_reduction_estimate"] = (report["merged_quartets"] * 3) + (report["merged_pairs"] * 1)
        report["resized_textures_to_512"] = len(self.resized_from_sources)
        after_mats, after_tex = self._count_used_materials_textures(mesh_objects)
        report["after_materials"] = after_mats
        report["after_textures"] = after_tex

        state = ExportAtlasState(
            self.scene,
            temp_collection,
            duplicated,
            self.created_images,
            self.created_materials,
        )
        return state, report

    def _duplicate_export_objects(self):
        temp_collection = bpy.data.collections.new("DCL_AtlasExport_Temp")
        self.scene.collection.children.link(temp_collection)

        obj_map = {}
        duplicated = []

        for obj in self.export_objects:
            dup = obj.copy()
            if obj.data:
                dup.data = obj.data.copy()
            temp_collection.objects.link(dup)
            obj_map[obj] = dup
            duplicated.append(dup)

        for orig, dup in obj_map.items():
            if orig.parent and orig.parent in obj_map:
                dup.parent = obj_map[orig.parent]
                dup.matrix_parent_inverse = orig.matrix_parent_inverse.copy()

        return temp_collection, duplicated

    def _count_used_materials_textures(self, mesh_objects):
        mats = set()
        images = set()

        for obj in mesh_objects:
            for mat in obj.data.materials:
                if not mat:
                    continue
                mats.add(mat.name)
                if mat.use_nodes and mat.node_tree:
                    for node in mat.node_tree.nodes:
                        if node.type == 'TEX_IMAGE' and node.image:
                            images.add(node.image.name)

        return len(mats), len(images)

    def _collect_candidates(self, mesh_objects, report):
        unique_materials = []
        seen = set()

        for obj in mesh_objects:
            mesh = obj.data
            if not mesh or not mesh.materials:
                continue

            used_indices = set()
            for poly in mesh.polygons:
                used_indices.add(poly.material_index)

            for idx in sorted(used_indices):
                if idx < 0 or idx >= len(mesh.materials):
                    continue
                mat = mesh.materials[idx]
                if mat and mat.name not in seen:
                    unique_materials.append(mat)
                    seen.add(mat.name)

        unique_materials.sort(key=lambda m: m.name)

        analysis = []
        for mat in unique_materials:
            result = self._analyze_material(mat)
            if result:
                analysis.append(result)
            elif self.debug_report:
                report["warnings"].append(f"Material '{mat.name}' not compatible with strict atlas rules")

        return analysis

    def _build_groups(self, analysis, report):
        buckets = {}
        for item in analysis:
            buckets.setdefault(item.key, []).append(item)

        groups = []
        # Always allow pair merge for v1 because this is the primary optimization target.
        allow_pairs = True
        for key in sorted(buckets.keys(), key=lambda x: str(x)):
            bucket = sorted(buckets[key], key=lambda x: x.material.name)
            while len(bucket) >= 4:
                groups.append({"items": bucket[:4], "layout": LAYOUT_4})
                bucket = bucket[4:]

            if allow_pairs:
                while len(bucket) >= 2:
                    groups.append({"items": bucket[:2], "layout": LAYOUT_2})
                    bucket = bucket[2:]

        # Fallback: if candidates exist but strict buckets produced no groups, pair by name.
        if not groups and allow_pairs and len(analysis) >= 2:
            ordered = sorted(analysis, key=lambda x: x.material.name)
            while len(ordered) >= 2:
                groups.append({"items": ordered[:2], "layout": LAYOUT_2})
                ordered = ordered[2:]
            if self.debug_report:
                report["warnings"].append(
                    "Forced pair merge used due to compatibility key mismatch"
                )

        return groups

    def _analyze_material(self, material):
        if not material.use_nodes or not material.node_tree:
            return None

        principled = self._find_principled(material)
        if not principled:
            return None

        base_input = self._socket_by_names(principled.inputs, ["Base Color"])
        normal_input = self._socket_by_names(principled.inputs, ["Normal"])
        rough_input = self._socket_by_names(principled.inputs, ["Roughness"])
        metal_input = self._socket_by_names(principled.inputs, ["Metallic"])

        if not base_input or not normal_input or not rough_input or not metal_input:
            return None

        base_image = self._extract_base_image(base_input)
        normal_extract = self._extract_normal_image_and_strength(normal_input)

        if not base_image:
            return None

        normal_image = None
        if normal_extract:
            normal_image, _normal_strength = normal_extract

        rough_source = self._extract_scalar_or_texture_source(rough_input)
        metal_source = self._extract_scalar_or_texture_source(metal_input)

        # Keep grouping tolerant so compatible-looking materials actually merge.
        # Emission and normal strength are intentionally ignored in v1 grouping.
        blend = material.blend_method
        alpha_key = round(float(getattr(material, "alpha_threshold", 0.5)), 4) if blend == 'CLIP' else 0.0
        key = (
            blend,
            alpha_key,
        )

        return MaterialAnalysis(
            material=material,
            key=key,
            base_image=base_image,
            normal_image=normal_image,
            rough_source=rough_source,
            metal_source=metal_source,
        )

    def _find_principled(self, material):
        tree = material.node_tree
        output = None
        for node in tree.nodes:
            if node.type == 'OUTPUT_MATERIAL' and getattr(node, 'is_active_output', False):
                output = node
                break
        if output:
            surf = output.inputs.get("Surface")
            if surf and surf.is_linked:
                from_node = surf.links[0].from_node
                if from_node and from_node.type == 'BSDF_PRINCIPLED':
                    return from_node

        for node in tree.nodes:
            if node.type == 'BSDF_PRINCIPLED':
                return node
        return None

    def _socket_by_names(self, socket_collection, names):
        for name in names:
            sock = socket_collection.get(name)
            if sock:
                return sock
        return None

    def _extract_base_image(self, input_socket):
        tex_node = self._trace_to_tex_image(input_socket)
        if not tex_node:
            return None
        return tex_node.image

    def _extract_normal_image_and_strength(self, input_socket):
        if not input_socket.is_linked:
            return None

        normal_node = input_socket.links[0].from_node
        if not normal_node:
            return None

        if normal_node.type == 'NORMAL_MAP':
            color_input = normal_node.inputs.get("Color")
            if not color_input or not color_input.is_linked:
                return None

            tex_node = self._trace_to_tex_image(color_input)
            if not tex_node:
                return None

            strength = normal_node.inputs.get("Strength")
            strength_val = strength.default_value if strength else 1.0
            return tex_node.image, strength_val

        if normal_node.type == 'TEX_IMAGE' and normal_node.image:
            return normal_node.image, 1.0

        tex_node = self._trace_to_tex_image(input_socket)
        if tex_node:
            return tex_node.image, 1.0
        return None

    def _extract_scalar_or_texture_source(self, input_socket):
        if not input_socket.is_linked:
            return ChannelSource(mode="SCALAR", scalar=float(input_socket.default_value))

        link = input_socket.links[0]
        from_node = link.from_node
        from_socket = link.from_socket

        if from_node and from_node.type == 'TEX_IMAGE' and from_node.image:
            channel = 0
            if from_socket.name == "Alpha":
                channel = 3
            return ChannelSource(mode="IMAGE", image=from_node.image, channel=channel)

        if from_node and from_node.type in {'SEPARATE_RGB', 'SEPARATE_COLOR'}:
            channel = self._channel_from_socket_name(from_socket.name)
            color_input = from_node.inputs.get("Image") or from_node.inputs.get("Color")
            if color_input and color_input.is_linked:
                tex_node = self._trace_to_tex_image(color_input)
                if tex_node and tex_node.image:
                    return ChannelSource(mode="IMAGE", image=tex_node.image, channel=channel)

        tex_node = self._trace_to_tex_image(input_socket)
        if tex_node and tex_node.image:
            return ChannelSource(mode="IMAGE", image=tex_node.image, channel=0)

        return ChannelSource(mode="SCALAR", scalar=float(input_socket.default_value))

    def _trace_to_tex_image(self, input_socket, depth=0, visited=None):
        if depth > 16:
            return None
        if not input_socket.is_linked:
            return None

        from_node = input_socket.links[0].from_node
        if not from_node:
            return None

        if visited is None:
            visited = set()
        node_key = (from_node.name, from_node.type)
        if node_key in visited:
            return None
        visited.add(node_key)

        if from_node.type == 'TEX_IMAGE' and from_node.image:
            return from_node

        if from_node.type in {'SEPARATE_RGB', 'SEPARATE_COLOR'}:
            upstream = from_node.inputs.get("Image") or from_node.inputs.get("Color")
            if upstream:
                return self._trace_to_tex_image(upstream, depth=depth + 1, visited=visited)

        for inp in from_node.inputs:
            if inp.is_linked:
                tex_node = self._trace_to_tex_image(inp, depth=depth + 1, visited=visited)
                if tex_node:
                    return tex_node

        return None

    def _channel_from_socket_name(self, name):
        lowered = (name or "").lower()
        if lowered in {"r", "red"}:
            return 0
        if lowered in {"g", "green"}:
            return 1
        if lowered in {"b", "blue"}:
            return 2
        if lowered in {"a", "alpha"}:
            return 3
        return 0

    def _is_emissive_enabled(self, principled):
        emission_socket = principled.inputs.get("Emission") or principled.inputs.get("Emission Color")
        if not emission_socket:
            return False
        if emission_socket.is_linked:
            return True
        val = emission_socket.default_value
        if hasattr(val, "__len__") and len(val) >= 3:
            return (val[0] > 0.0) or (val[1] > 0.0) or (val[2] > 0.0)
        return float(val) > 0.0

    def _build_atlas_material(self, group_index, group, layout):
        atlas_width = layout["width"]
        atlas_height = layout["height"]
        group_name = f"DCLAtlas_{group_index + 1}"
        size_label = f"{atlas_width}x{atlas_height}"

        base_img = self._new_image(f"{group_name}_BaseColor_{size_label}", "sRGB", atlas_width, atlas_height)
        orm_img = self._new_image(f"{group_name}_ORM_{size_label}", "Non-Color", atlas_width, atlas_height)
        normal_img = self._new_image(f"{group_name}_Normal_{size_label}", "Non-Color", atlas_width, atlas_height)

        base_pixels = [0.0] * (atlas_width * atlas_height * 4)
        orm_pixels = [0.0] * (atlas_width * atlas_height * 4)
        normal_pixels = [0.5] * (atlas_width * atlas_height * 4)

        # Defaults
        for i in range(0, len(base_pixels), 4):
            base_pixels[i + 3] = 1.0
            orm_pixels[i + 0] = 1.0  # AO
            orm_pixels[i + 3] = 1.0
            normal_pixels[i + 2] = 1.0
            normal_pixels[i + 3] = 1.0

        for tile_idx, item in enumerate(group):
            x_off, y_off = layout["tiles"][tile_idx]
            self._blit_rgba(item.base_image, base_pixels, atlas_width, x_off, y_off)
            if item.normal_image:
                self._blit_rgba(item.normal_image, normal_pixels, atlas_width, x_off, y_off)
            else:
                self._fill_flat_normal_tile(normal_pixels, atlas_width, x_off, y_off)
            self._blit_orm(item.rough_source, item.metal_source, orm_pixels, atlas_width, x_off, y_off)

        # Guardrails: avoid exporting broken black maps when source extraction fails.
        if self._is_rgb_black(normal_pixels):
            self._fill_flat_normal_full(normal_pixels)
        if self._is_green_blue_black(orm_pixels):
            self._fill_orm_neutral(orm_pixels)

        base_img.pixels[:] = base_pixels
        orm_img.pixels[:] = orm_pixels
        normal_img.pixels[:] = normal_pixels
        base_img.update()
        orm_img.update()
        normal_img.update()

        atlas_mat = bpy.data.materials.new(name=f"{group_name}_Material")
        atlas_mat.use_nodes = True
        atlas_mat.blend_method = group[0].material.blend_method
        if hasattr(atlas_mat, "shadow_method") and hasattr(group[0].material, "shadow_method"):
            atlas_mat.shadow_method = group[0].material.shadow_method
        atlas_mat.use_backface_culling = group[0].material.use_backface_culling
        if hasattr(atlas_mat, "alpha_threshold"):
            atlas_mat.alpha_threshold = getattr(group[0].material, "alpha_threshold", 0.5)

        nodes = atlas_mat.node_tree.nodes
        links = atlas_mat.node_tree.links
        nodes.clear()

        out = nodes.new(type='ShaderNodeOutputMaterial')
        out.location = (600, 0)
        bsdf = nodes.new(type='ShaderNodeBsdfPrincipled')
        bsdf.location = (300, 0)

        tex_base = nodes.new(type='ShaderNodeTexImage')
        tex_base.image = base_img
        tex_base.label = "BaseColor"
        tex_base.location = (-400, 150)

        tex_orm = nodes.new(type='ShaderNodeTexImage')
        tex_orm.image = orm_img
        tex_orm.label = "ORM"
        tex_orm.image.colorspace_settings.name = "Non-Color"
        tex_orm.location = (-400, -30)

        try:
            sep = nodes.new(type='ShaderNodeSeparateRGB')
            sep_green = "G"
            sep_blue = "B"
        except Exception:
            sep = nodes.new(type='ShaderNodeSeparateColor')
            sep_green = "Green"
            sep_blue = "Blue"
        sep.location = (-150, -40)

        tex_n = nodes.new(type='ShaderNodeTexImage')
        tex_n.image = normal_img
        tex_n.label = "Normal"
        tex_n.image.colorspace_settings.name = "Non-Color"
        tex_n.location = (-400, -220)

        uv_map = nodes.new(type='ShaderNodeUVMap')
        uv_map.location = (-650, -40)
        uv_map.uv_map = "DCL_AtlasUV"

        normal_map = nodes.new(type='ShaderNodeNormalMap')
        normal_map.location = (-150, -220)
        normal_map.space = 'TANGENT'
        normal_map.inputs["Strength"].default_value = 1.0

        links.new(tex_base.outputs["Color"], bsdf.inputs["Base Color"])
        if "Alpha" in tex_base.outputs and "Alpha" in bsdf.inputs:
            links.new(tex_base.outputs["Alpha"], bsdf.inputs["Alpha"])

        links.new(uv_map.outputs["UV"], tex_base.inputs["Vector"])
        links.new(uv_map.outputs["UV"], tex_orm.inputs["Vector"])
        links.new(uv_map.outputs["UV"], tex_n.inputs["Vector"])

        links.new(tex_orm.outputs["Color"], sep.inputs[0])
        links.new(sep.outputs[sep_green], bsdf.inputs["Roughness"])
        links.new(sep.outputs[sep_blue], bsdf.inputs["Metallic"])

        links.new(tex_n.outputs["Color"], normal_map.inputs["Color"])
        links.new(normal_map.outputs["Normal"], bsdf.inputs["Normal"])

        links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])

        self.created_materials.append(atlas_mat)
        return atlas_mat

    def _new_image(self, name, colorspace_name, width, height):
        img = bpy.data.images.new(name=name, width=width, height=height, alpha=True)
        img.generated_color = (0.0, 0.0, 0.0, 1.0)
        img.colorspace_settings.name = colorspace_name
        self.created_images.append(img)
        return img

    def _normalize_image_to_512(self, image):
        # Legacy hook kept for compatibility. Atlas build now resamples on read.
        return image

    def _image_pixels(self, image):
        cache_key = image.name
        cached = self.pixel_cache.get(cache_key)
        if cached is None:
            try:
                if image.source == 'FILE' and image.filepath and not image.packed_file:
                    image.reload()
            except Exception:
                pass
            cached = list(image.pixels[:])
            expected = int(image.size[0]) * int(image.size[1]) * 4
            if expected > 0 and len(cached) != expected:
                # Fallback to opaque black to avoid index errors on malformed buffers.
                cached = [0.0] * expected
                for i in range(3, len(cached), 4):
                    cached[i] = 1.0
            self.pixel_cache[cache_key] = cached
        return cached

    def _blit_rgba(self, src_image, dst_pixels, atlas_width, x_off, y_off):
        src_pixels = self._image_pixels(src_image)
        src_w = max(1, int(src_image.size[0]))
        src_h = max(1, int(src_image.size[1]))
        if src_w != TILE_SIZE or src_h != TILE_SIZE:
            self.resized_from_sources.add(src_image.name)

        for y in range(TILE_SIZE):
            src_y = min(src_h - 1, int((y + 0.5) * src_h / TILE_SIZE))
            dst_row = (y + y_off) * atlas_width
            for x in range(TILE_SIZE):
                src_x = min(src_w - 1, int((x + 0.5) * src_w / TILE_SIZE))
                src_i = (src_y * src_w + src_x) * 4
                dst_i = (dst_row + x + x_off) * 4
                dst_pixels[dst_i:dst_i + 4] = src_pixels[src_i:src_i + 4]

    def _blit_orm(self, rough_source, metal_source, dst_pixels, atlas_width, x_off, y_off):
        rough_pixels = None
        metal_pixels = None
        rough_w = rough_h = 1
        metal_w = metal_h = 1

        if rough_source.mode == "IMAGE":
            rough_img = rough_source.image
            rough_pixels = self._image_pixels(rough_img)
            rough_w = max(1, int(rough_img.size[0]))
            rough_h = max(1, int(rough_img.size[1]))
            if rough_w != TILE_SIZE or rough_h != TILE_SIZE:
                self.resized_from_sources.add(rough_img.name)

        if metal_source.mode == "IMAGE":
            metal_img = metal_source.image
            metal_pixels = self._image_pixels(metal_img)
            metal_w = max(1, int(metal_img.size[0]))
            metal_h = max(1, int(metal_img.size[1]))
            if metal_w != TILE_SIZE or metal_h != TILE_SIZE:
                self.resized_from_sources.add(metal_img.name)

        for y in range(TILE_SIZE):
            rough_y = min(rough_h - 1, int((y + 0.5) * rough_h / TILE_SIZE))
            metal_y = min(metal_h - 1, int((y + 0.5) * metal_h / TILE_SIZE))
            dst_row = (y + y_off) * atlas_width
            for x in range(TILE_SIZE):
                dst_i = (dst_row + x + x_off) * 4

                if rough_pixels:
                    rough_x = min(rough_w - 1, int((x + 0.5) * rough_w / TILE_SIZE))
                    rough_i = (rough_y * rough_w + rough_x) * 4
                    rough_val = rough_pixels[rough_i + rough_source.channel]
                else:
                    rough_val = rough_source.scalar

                if metal_pixels:
                    metal_x = min(metal_w - 1, int((x + 0.5) * metal_w / TILE_SIZE))
                    metal_i = (metal_y * metal_w + metal_x) * 4
                    metal_val = metal_pixels[metal_i + metal_source.channel]
                else:
                    metal_val = metal_source.scalar

                dst_pixels[dst_i + 0] = 1.0
                dst_pixels[dst_i + 1] = rough_val
                dst_pixels[dst_i + 2] = metal_val
                dst_pixels[dst_i + 3] = 1.0

    def _fill_flat_normal_tile(self, dst_pixels, atlas_width, x_off, y_off):
        for y in range(TILE_SIZE):
            dst_row = (y + y_off) * atlas_width
            for x in range(TILE_SIZE):
                dst_i = (dst_row + x + x_off) * 4
                dst_pixels[dst_i + 0] = 0.5
                dst_pixels[dst_i + 1] = 0.5
                dst_pixels[dst_i + 2] = 1.0
                dst_pixels[dst_i + 3] = 1.0

    def _fill_flat_normal_full(self, dst_pixels):
        for i in range(0, len(dst_pixels), 4):
            dst_pixels[i + 0] = 0.5
            dst_pixels[i + 1] = 0.5
            dst_pixels[i + 2] = 1.0
            dst_pixels[i + 3] = 1.0

    def _is_rgb_black(self, pixels):
        pixel_count = len(pixels) // 4
        step = max(1, pixel_count // 2048)
        for p in range(0, pixel_count, step):
            i = p * 4
            if (pixels[i + 0] > 0.001) or (pixels[i + 1] > 0.001) or (pixels[i + 2] > 0.001):
                return False
        return True

    def _is_green_blue_black(self, pixels):
        pixel_count = len(pixels) // 4
        step = max(1, pixel_count // 2048)
        for p in range(0, pixel_count, step):
            i = p * 4
            if (pixels[i + 1] > 0.001) or (pixels[i + 2] > 0.001):
                return False
        return True

    def _fill_orm_neutral(self, pixels):
        for i in range(0, len(pixels), 4):
            pixels[i + 0] = 1.0
            pixels[i + 1] = 0.5
            pixels[i + 2] = 0.0
            pixels[i + 3] = 1.0

    def _apply_group(self, mesh_objects, group, layout, atlas_material):
        tile_by_name = {}
        for idx, item in enumerate(group):
            tile_by_name[item.material.name] = idx
        tile_hits = [0] * len(group)

        atlas_width = float(layout["width"])
        atlas_height = float(layout["height"])
        u_scale = TILE_SIZE / atlas_width
        v_scale = TILE_SIZE / atlas_height

        for obj in mesh_objects:
            mesh = obj.data
            if not mesh.materials:
                continue

            slot_map = {}
            for idx, mat in enumerate(mesh.materials):
                if mat and mat.name in tile_by_name:
                    slot_map[idx] = tile_by_name[mat.name]

            if not slot_map:
                continue

            src_uv = self._get_source_uv_layer(mesh)
            if src_uv is None:
                src_uv = mesh.uv_layers.new(name="UVMap")

            atlas_uv = mesh.uv_layers.get("DCL_AtlasUV")
            if atlas_uv is None:
                atlas_uv = mesh.uv_layers.new(name="DCL_AtlasUV")

            self._copy_uv_layer_fast(src_uv, atlas_uv)

            self._set_active_uv_layer(mesh, atlas_uv)

            atlas_slot = len(mesh.materials)
            mesh.materials.append(atlas_material)

            uv_data = self._get_uv_data_fast(atlas_uv)

            for poly in mesh.polygons:
                tile_idx = slot_map.get(poly.material_index)
                if tile_idx is None:
                    continue

                tile_hits[tile_idx] += 1

                x_off, y_off = layout["tiles"][tile_idx]
                u_off = x_off / atlas_width
                v_off = y_off / atlas_height

                for li in poly.loop_indices:
                    bi = li * 2
                    uv_data[bi + 0] = (uv_data[bi + 0] * u_scale) + u_off
                    uv_data[bi + 1] = (uv_data[bi + 1] * v_scale) + v_off

                poly.material_index = atlas_slot

            self._set_uv_data_fast(atlas_uv, uv_data)
            self._broadcast_atlas_uv(mesh, atlas_uv)
            self._compact_material_slots(mesh)

        for tile_idx, hits in enumerate(tile_hits):
            if hits == 0:
                raise RuntimeError(
                    f"Tile {tile_idx + 1} ({group[tile_idx].material.name}) had no mapped polygons"
                )

    def _get_source_uv_layer(self, mesh):
        uv_layers = mesh.uv_layers
        if not uv_layers:
            return None

        for layer in uv_layers:
            if hasattr(layer, "active_render") and layer.active_render:
                return layer

        if uv_layers.active:
            return uv_layers.active

        return uv_layers[0]

    def _set_active_uv_layer(self, mesh, uv_layer):
        uv_layers = mesh.uv_layers
        target_index = None

        for i, layer in enumerate(uv_layers):
            if layer.name == uv_layer.name:
                target_index = i
                break

        try:
            uv_layers.active = uv_layer
        except Exception:
            if target_index is not None and hasattr(uv_layers, "active_index"):
                uv_layers.active_index = target_index

        if target_index is not None and hasattr(uv_layers, "active_index"):
            uv_layers.active_index = target_index

        if hasattr(uv_layer, "active_render"):
            try:
                uv_layer.active_render = True
            except Exception:
                pass
        elif target_index is not None and hasattr(uv_layers, "active_render_index"):
            try:
                uv_layers.active_render_index = target_index
            except Exception:
                pass

    def _broadcast_atlas_uv(self, mesh, atlas_uv):
        # glTF may bind TEXCOORD_0/1 depending on node graph and exporter decisions.
        # Mirror atlas UVs to all layers in temp meshes so any chosen channel is valid.
        uv_layers = mesh.uv_layers
        source_name = atlas_uv.name
        src_data = self._get_uv_data_fast(atlas_uv)

        for layer in uv_layers:
            if layer.name == source_name:
                continue
            self._set_uv_data_fast(layer, src_data)

    def _get_uv_data_fast(self, uv_layer):
        count = len(uv_layer.data) * 2
        data = [0.0] * count
        uv_layer.data.foreach_get("uv", data)
        return data

    def _set_uv_data_fast(self, uv_layer, data):
        target_count = len(uv_layer.data) * 2
        if len(data) != target_count:
            # Resize for safety if layer sizes differ.
            if len(data) > target_count:
                payload = data[:target_count]
            else:
                payload = data + [0.0] * (target_count - len(data))
        else:
            payload = data
        uv_layer.data.foreach_set("uv", payload)

    def _copy_uv_layer_fast(self, src_uv, dst_uv):
        src = self._get_uv_data_fast(src_uv)
        self._set_uv_data_fast(dst_uv, src)

    def _compact_material_slots(self, mesh):
        if not mesh.polygons or not mesh.materials:
            return

        used = sorted(set(poly.material_index for poly in mesh.polygons))
        if not used:
            return

        if used == list(range(len(mesh.materials))):
            return

        old_mats = list(mesh.materials)
        remap = {old_idx: new_idx for new_idx, old_idx in enumerate(used)}

        for poly in mesh.polygons:
            poly.material_index = remap[poly.material_index]

        while len(mesh.materials) > 0:
            mesh.materials.pop(index=len(mesh.materials) - 1)
        for old_idx in used:
            mesh.materials.append(old_mats[old_idx])

    def _ensure_consistent_atlas_uv(self, mesh, atlas_material):
        # If this mesh ended with only atlas material, keep only atlas UV so it is TEXCOORD_0.
        if len(mesh.materials) != 1 or mesh.materials[0] != atlas_material:
            return

        atlas_uv = mesh.uv_layers.get("DCL_AtlasUV")
        if atlas_uv is None:
            return

        for layer in list(mesh.uv_layers):
            if layer.name != atlas_uv.name:
                mesh.uv_layers.remove(layer)

        atlas_uv = mesh.uv_layers.get("DCL_AtlasUV")
        if atlas_uv is None and len(mesh.uv_layers) > 0:
            atlas_uv = mesh.uv_layers[0]
            atlas_uv.name = "DCL_AtlasUV"

        if atlas_uv:
            self._set_active_uv_layer(mesh, atlas_uv)



def run_material_atlas_optimization(context, export_objects, mode='STRICT_2_OR_4_512_TO_1024', debug_report=True):
    optimizer = MaterialAtlasOptimizer(context, export_objects, mode=mode, debug_report=debug_report)
    return optimizer.run()
